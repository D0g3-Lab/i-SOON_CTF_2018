package com.example.androidx;


import android.os.Looper;
import android.os.StrictMode;
import android.os.SystemClock;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Base64;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.security.MessageDigest;
import java.security.PrivateKey;

public class MainActivity extends AppCompatActivity {
    private EditText name;
    private EditText pass;
    private Button btn1;
    private String x;
    private String result;
    private int returnResult;
    private String user_id;
    private String input_pwd;
    private int c;
    private String decryptStr;
    private String pas;

    private static String PRIVATE_KEY = "MIICdgIBADANBgkqhkiG9w0BAQEFAASCAmAwggJcAgEAAoGBALI8zkJx0K9l124o"
            + "\r" + "NAIWgH/oeF7oeNIxpXeDc5CN663aH6vOU9zBq+ojXHI0h+cAmB1GwUWoI45MJBNf" + "\r"
            + "7647VZ2GAISlET5wsoftSRW8QMe5c+Kg5IM0nIDb0B8gEapkt8H0+KIkg6y8ahbR" + "\r"
            + "P02vFrpI3/XKBbm3BFTUNqo2MDUhAgMBAAECgYEAiswVJuLwypW5FHxUO8gAGxsS" + "\r"
            + "GX5ZD/4/R3ljFg+el0zD2wuafM+Iq5UL2ZeUuUvaKPo/aZoMzjP25+uOfxSPjwUT" + "\r"
            + "0gqb/otOJ81HSKCkcD3UFDxDQ0AIQo1Ce0OgNgqqtgpFvWczH4oZNe6B4N8PqsRW" + "\r"
            + "mdHrNOT8GJw9bXN36AECQQDlS8lAUVnxD5xSaB7eAYf+541b6L3YXboUKr6lUs9Y" + "\r"
            + "FZWNohwEsgVNGFwA2qhhbSNEzTRO8MiqCwzH//EjdkBBAkEAxv7D1q/Dy/QvyuXp" + "\r"
            + "JjlD5pvK5t9pd7x70hl6eQM3tq1/FIb3dwCWKwfKk4SWNcSMMi4VQ2CNG45InOPK" + "\r"
            + "z5K84QJAYrL2k/rwjjU8ArTS5JkgIvck//T1Exd1K40ityMoITBZSbgH+3Vtlrvv" + "\r"
            + "jmaQqC9ESS9TXs+CcL+E5uoisDMMgQJAIUEh6RamWccM1ZNmSwT22+rdFYfwUBon" + "\r"
            + "dwza8q4e+WA1BHEpmbF3Zul+aPiXQZT++MPKud/AtQIqEE3g7p9PAQJAJQ9wvTki" + "\r"
            + "7sZKSuXLjNaAg4lxRg7KVqgDIbnnG3nU4WZv33T49a5aBLvuKn3V87ZWXPE1Jw5X" + "\r" + "BBQQCqGI9HjwOQ=="
            + "\r";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Exception();
        btn1 = (Button) findViewById(R.id.button);
        //监听button事件
        btn1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (ButtonUtil.isFastDoubleClick()) {
                    Toast.makeText(getApplicationContext(), "每2秒只能点击一次，否则点击无效", Toast.LENGTH_SHORT).show();
                } else {
                    name = (EditText) findViewById(R.id.u_name);
                    pass = (EditText) findViewById(R.id.u_pass);
                    user_id = name.getText().toString();
                    input_pwd = pass.getText().toString();
                    byte b[] = user_id.getBytes();
                    for (int i = 0; i < user_id.length(); i++) {
                        b[i] = (byte) (b[i] ^ 0x8);
                    }
                    pas = new String(b);
                    char hexDigits[] = {'0', '1', '2', '3', '4', '5', '6', '7', '8', '9', 'A', 'B', 'C', 'D', 'E', 'F'};
                    try {
                        byte[] btInput = pas.getBytes();
                        // 获得MD5摘要算法的 MessageDigest 对象
                        MessageDigest mdInst = MessageDigest.getInstance("MD5");
                        // 使用指定的字节更新摘要
                        mdInst.update(btInput);
                        // 获得密文
                        byte[] md = mdInst.digest();
                        // 把密文转换成十六进制的字符串形式
                        int j = md.length;
                        char str[] = new char[j * 2];
                        int k = 0;
                        for (int i = 0; i < j; i++) {
                            byte byte0 = md[i];
                            str[k++] = hexDigits[byte0 >>> 4 & 0xf];
                            str[k++] = hexDigits[byte0 & 0xf];
                            pas = String.valueOf(str);
                        }
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                    try {
                        int issucc = login();
                        String s = decode();
                        String s1 = new String(Base64.decode(s.getBytes(), Base64.DEFAULT));
                        String s2 = encode(s1, "79846431");
                        if (issucc == 1) {
                            Toast.makeText(MainActivity.this, x + "\nflag：" + s2, Toast.LENGTH_LONG).show();
                        } else {
                            Toast.makeText(MainActivity.this, x, Toast.LENGTH_LONG).show();
                        }
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                }
            }
        });
    }

    private int login() throws IOException {
        returnResult = 0;
        /*获取用户名和密码*/
        if (user_id == null || user_id.length() == 0) {
            new Thread() {
                public void run() {

                    Looper.prepare();
                    Toast.makeText(MainActivity.this, "请输入账号", Toast.LENGTH_LONG).show();
                    Looper.loop();
                }
            }.start();

        }
        if (pas!="38068D122798021D60FD50D744D43DCB"&&input_pwd.length() == 0) {
            new Thread() {
                public void run() {
                    Looper.prepare();
                    Toast.makeText(MainActivity.this, "密码错误或未输入密码", Toast.LENGTH_LONG).show();
                    Looper.loop();
                }
            }.start();
        }
        Thread t1 = new Thread(new T1());
        t1.start();
        try {
            t1.join();
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        return c;
    }
public String decode()
{
    try
    {
        String encryptContent;
        if(x.equals("login success but not vip")||x.equals("password error"))
        {
            encryptContent ="NKNU109nrSZ7VObqGmvYienSJNArcZCtXnKw2GODL/aDyWl/loFlNwH4sJn0RKNRoP9znS1zDz5tWviYvv3FViuyRnZF6pzN78+GVya6l4MaK8m6c6DWXXp9YwL1RuuctvIUV/H6gdYxbEgq41VmttbTgnIzV9vtdubN6Q+t7cw=";
        }
        else {
            encryptContent = x;
        }
        // 从字符串中得到私钥
        PrivateKey privateKey = RSAUtils.loadPrivateKey(PRIVATE_KEY);
        // 因为RSA加密后的内容经Base64再加密转换了一下，所以先Base64解密回来再给RSA解密
        byte[] decryptByte = RSAUtils.decryptData(Base64Utils.decode(encryptContent), privateKey);
        decryptStr  = new String(decryptByte);

        System.out.println("x="+decryptStr );
    } catch (Exception e)
    {
        e.printStackTrace();
    }
    return decryptStr;
}

    //Value <br of type java.lang.String cannot be converted to JSONObject
    /*JSONObject jsonObject = new JSONObject(JSONTokener(result));*/
    public String JSONTokener(String in) {
        // consume an optional byte order mark (BOM) if it exists
        if (in != null && in.startsWith("\ufeff")) {
            in = in.substring(1);
        }
        return in;
    }
    public static String encode(String aInput, String aKey) {
        int[] iS = new int[256];
        byte[] iK = new byte[256];

        for (int i = 0; i < 256; i++)
            iS[i] = i;

        int j = 1;

        for (short i = 0; i < 256; i++) {
            iK[i] = (byte) aKey.charAt((i % aKey.length()));
        }

        j = 0;

        for (int i = 0; i < 255; i++) {
            j = (j + iS[i] + iK[i]) % 256;
            int temp = iS[i];
            iS[i] = iS[j];
            iS[j] = temp;
        }


        int i = 0;
        j = 0;
        char[] iInputChar = aInput.toCharArray();
        char[] iOutputChar = new char[iInputChar.length];
        for (short x = 0; x < iInputChar.length; x++) {
            i = (i + 1) % 256;
            j = (j + iS[i]) % 256;
            int temp = iS[i];
            iS[i] = iS[j];
            iS[j] = temp;
            int t = (iS[i] + (iS[j] % 256)) % 256;
            int iY = iS[t];
            char iCY = (char) iY;
            iOutputChar[x] = (char) (iInputChar[x] ^ iCY);
        }

        return new String(iOutputChar);

    }
    public void Exception() {
        //避免出现android.os.NetworkOnMainThreadException异常
        StrictMode.setThreadPolicy(new StrictMode.ThreadPolicy.Builder()
                .detectDiskReads().detectDiskWrites().detectNetwork()
                .penaltyLog().build());

        StrictMode.setVmPolicy(new StrictMode.VmPolicy.Builder()
                .detectLeakedSqlLiteObjects().detectLeakedClosableObjects()
                .penaltyLog().penaltyDeath().build());
    }
    class T1 implements Runnable {
        public void run() {
            try {
                URL url = new URL("http://202.182.110.183/login.php");
                HttpURLConnection conn = (HttpURLConnection) url.openConnection();
                String params = "uid=" + user_id + '&' + "pwd=" + input_pwd;
                conn.setDoOutput(true);
                conn.setConnectTimeout(5000);
                conn.setReadTimeout(5000);
                conn.setRequestMethod("POST");
                conn.getOutputStream().write(params.getBytes());
                if (conn.getResponseCode() != 200) {
                    System.out.println("请求失败");
                    return;
                } else {
                    System.out.println("请求成功");
                }
                InputStream inStream = conn.getInputStream();
                ByteArrayOutputStream baos = new ByteArrayOutputStream();
                int len = 0;
                byte[] buf = new byte[1024];
                while ((len = inStream.read(buf)) != -1) {
                    baos.write(buf, 0, len);
                }
                result = new String(baos.toByteArray());
                inStream.close();
                JSONObject jsonObject = new JSONObject(JSONTokener(result));
                returnResult = jsonObject.getInt("status");//获取JSON数据中status字段值
                x = jsonObject.getString("info");
                c = returnResult;
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    }

}

