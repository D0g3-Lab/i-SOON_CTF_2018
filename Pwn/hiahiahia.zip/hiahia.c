#include<stdio.h>

void here()
{
	char *s="CTF{Here's the flag on server}";
	char buffer[100];
	printf("Hello!\nWe meet again? \n");
    printf("Please find the flag!\n");
    scanf("%s", buffer);
    printf("bey~ bey~ bey~\n");
}

int main(void)
{
	setbuf(stdout, 0LL);
	here();
    
    return 0;
}
