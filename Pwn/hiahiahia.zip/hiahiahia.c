#include<stdio.h>

void here()
{
	char *s="D0g3{ccc_y0u_again_hiahiahia_}";
	char buffer[100];
	printf("Hello!\nWe meet again? \n");
    printf("Please find the flag!\n");
    scanf("%s", buffer);
    printf("bey~ bey~ bey~\n");
}

int main(void)
{
	setbuf(stdout, 0LL);
	here();
    
    return 0;
}
