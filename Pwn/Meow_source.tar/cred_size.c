#include <linux/cred.h>
#include <linux/module.h>
#include <linux/types.h>
#include <linux/init.h>

MODULE_LICENSE("GPL");
MODULE_AUTHOR("Edvison");

struct cred cred;

static int test_init(void)
{
	printk("The cred size is:%d\n", sizeof(struct cred));
	return 0;
}

static void test_exit(void)
{
	printk("exit!");
	
}

module_init(test_init);
module_exit(test_exit);

