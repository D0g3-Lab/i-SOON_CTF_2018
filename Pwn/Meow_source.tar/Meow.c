#include <linux/module.h>
#include <linux/types.h>
#include <linux/kernel.h>
#include <linux/fs.h>
#include <linux/errno.h>
#include <linux/cdev.h>
#include <asm/uaccess.h>
#include <linux/device.h>
#include<linux/slab.h>
#include<linux/string.h>


MODULE_LICENSE("GPL");
MODULE_AUTHOR("Edvison");

int Meow_major = 233;
struct class *Meow_class;
struct cdev cdev;

struct Meow
{
	size_t len;
	char *buf;
};

struct Meow me;

static ssize_t Meow_write(struct file *filp, const char __user *ubuf, size_t count, loff_t *position)
{	
#ifdef DEBUG	
	printk("Meow: called write\n");
#endif
	me.len = count;
	
	if (copy_from_user(me.buf, ubuf, count)) {
		printk("copy error\n");
		return -EFAULT;
	}
#ifdef DEBUG	
	printk("current: %p, size: %d, buf:%p\n", current, me.len, me.buf);
	printk("buf(%p), content: %s\n", me.buf, me.buf);
#endif
	printk("Meow: write success\n");
	
	return count;
}

static ssize_t Meow_read(struct file *filp, char __user *ubuf, size_t count, loff_t *position)
{
#ifdef DEBUG	
	printk("Meow: called read\n");
#endif	
	if(*position >= me.len)
		return 0;
		
	if(*position + count > me.len)
		count = me.len - *position;
	
	if(copy_to_user(ubuf, me.buf + *position, me.len))
	{
		printk("copy error\n");
		return -EFAULT;
	}
#ifdef DEBUG	
	printk("buf(%p), content: %s\n", ubuf, ubuf);
#endif
	printk("Meow: read success\n");
	
	*position += count;
	
	return count;
}

int Meow_ioctl(struct file *filp, unsigned int cmd, unsigned long arg)
{
	
	if(cmd == 0x4d656f77)
	{
		kfree(me.buf);
#ifdef DEBUG
		printk("kfree: %p\n", me.buf);
#endif		
		me.buf = kmalloc(arg, GFP_KERNEL);
		me.len = arg;
#ifdef DEBUG
		printk("kmalloc: %p\n", me.buf);
#endif
	}
	else
	{
		printk("ioctl error\n");
		return -1;
	}
	
	printk("Meow: alloc success\n");
	return 0;	
}


static int Meow_release(struct inode *inode, struct file *filp)
{
	
	kfree(me.buf);
	printk("Meow: release success\n");
	return 0;
}

static int Meow_open(struct inode *inode, struct file *filp)
{
	
	me.buf = kmalloc(sizeof(struct Meow), GFP_KERNEL);
	me.len = 64;
	
	printk("Meow: open success\n");
	return 0;
}

static const struct file_operations Meow_fops = {
	.owner = THIS_MODULE,
	.unlocked_ioctl = Meow_ioctl,
	.read = Meow_read,
	.write = Meow_write,
	.release = Meow_release,
	.open = Meow_open,
};

static int Meow_init(void)
{
	int result;
	dev_t devno = MKDEV(Meow_major, 0);
	
	if(Meow_major)
		result = register_chrdev_region(devno, 1, "Meow");
	else
	{
		result = alloc_chrdev_region(&devno, 0, 1, "Meow");
		Meow_major = MAJOR(devno);
	}
#ifdef DEBUG	
	printk("Meow_major /dev/Meow: %d\n", Meow_major);
#endif
	if(result < 0)
		return -1;
		
	Meow_class = class_create(THIS_MODULE, "Meow");
	device_create(Meow_class, NULL, devno, NULL, "Meow");
	
	cdev_init(&cdev, &Meow_fops);
	cdev.owner = THIS_MODULE;
	cdev_add(&cdev, devno, 1);
#ifdef DEBUG	
	printk("Meow: init success\n");
#endif	
	return 0;
}

static void Meow_exit(void)
{
	cdev_del(&cdev);
	device_destroy(Meow_class, MKDEV(Meow_major, 0));
	class_destroy(Meow_class);
	unregister_chrdev_region(MKDEV(Meow_major, 0), 1);
	printk("Meow: exit success\n");
}

module_init(Meow_init);
module_exit(Meow_exit);
	
	
